document.getElementById("formulariojugador").addEventListener("submit", function(e) {

    e.preventDefault();

    let valido = true;

    
    document.getElementById("error-nombre").textContent = "";
    document.getElementById("error-email").textContent = "";
    document.getElementById("error-password").textContent = "";
    document.getElementById("error-edad").textContent = "";

    const nombre = document.getElementById("name");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const edad = document.getElementById("edad");


    if (!nombre || !email || !password || !edad) {
        console.log("Error: algún input no existe en el DOM");
    }   


    


    if (nombre.value.trim() === "") {

        document.getElementById("error-nombre").textContent = "El nombre es obligatorio";
        nombre.classList.add("input-error");
        valido = false;
    } else {
        nombre.classList.remove("input-error");
    }

    
    if (email.value.trim() === "") {
        document.getElementById("error-email").textContent = "El email es obligatorio";
        email.classList.add("input-error");
        valido = false;
    } else {
        email.classList.remove("input-error");
    }



    if (password.value.trim() === "") {
        document.getElementById("error-password").textContent = "la contraseña es obligatorio";
        password.classList.add("input-error");
        valido = false;
    } else {
        password.classList.remove("input-error");
    }

      if (edad.value.trim() === "") {
        document.getElementById("error-edad").textContent = "la edad es obligatoria";
        edad.classList.add("input-error");
        valido = false;
    } else {
        email.classList.remove("input-error");
    }



   
    
    if (password.value.length < 4) {
        document.getElementById("error-password").textContent = "Mínimo 4 caracteres";
        password.classList.add("input-error");
        valido = false;
    } else {
        password.classList.remove("input-error");
    }


    const formatoEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!formatoEmail.test(email.value)) {
            document.getElementById("error-email").textContent =
                "Ingrese un email válido";
            valido = false;
        }
    

  



    const caracteresEspeciales = password.value.match(/[!@#$%^&*(),.?":{}|<>]/g);

        if (!caracteresEspeciales || caracteresEspeciales.length < 3) {
            document.getElementById("error-password").textContent =
                "La contraseña debe contener al menos 3 caracteres especiales";
            valido = false;
        }
            
        
  
    if (valido) {

        const usuario = document.createElement("p");

        usuario.textContent = nombre.value + " - " + email.value;

        document.getElementById("form-container").append(usuario);



            this.submit(); 
        }

});

    
document.getElementById("name").addEventListener("input", function() {

    document.getElementById("eventoinput").textContent =
        "Escribiendo datos |🔹| "

});

