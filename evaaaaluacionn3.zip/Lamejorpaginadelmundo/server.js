const express = require('express');
const mysql = require('mysql2');
const bodyparser =require('body-parser');
const cors = require('cors');
const path = require('path');
const { error } = require('console');

const app = express();
const puerto = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

app.use(express.urlencoded({extended: true}));


const db = mysql.createConnection({

    host:'localhost',
    user:'root',
    password:'',
    database:'DBxd3'


})

db.connect((error)=>{

    if(error){
        console.log("Error no se pudo conectar al a base da datos")
    }

    console.log("Conectando a la base de datos mysql")


})




app.post('/guardar',(req,res)=>{

    const nombre = req.body.name;
    const email = req.body.email;
    const contrasena = req.body.password;
    const edad = req.body.edad;

    console.log("capturando datos " + nombre, email,contrasena)

 


    const sql = "INSERT INTO jugador (name,email,password,edad) VALUES (?,?,?,?); "

    db.query(sql,[nombre,email,contrasena,edad],(err,result)=>{

        if(err){
            console.log(err);
            return res.status(500).send("Error al guardar usuario");
        }

        return res.send("Usuario Guardado")


    });

});

app.get('/',(req,res)=>{

    res.sendFile(path.join(__dirname, 'Views/lobby.html'));

})



app.get('/index',(req,res)=>{
    res.sendFile(path.join(__dirname,'Views/index.html'))
})


app.get('/registro',(req,res)=>{

    res.sendFile(path.join(__dirname,'Views/registro.html'))


})
































app.listen(puerto,(req,res)=>{

    console.log("Escuchando puerto http://localhost:3000")


})