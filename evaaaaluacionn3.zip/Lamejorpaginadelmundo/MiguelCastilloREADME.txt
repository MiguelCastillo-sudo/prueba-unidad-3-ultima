Fecha 25 / 08 / 2026 hola intento de primer commit asd asdas (no supe conectar github)

(me dio error)



base de datos : 


http://localhost/phpmyadmin

CREATE DATA BASE DBxd3;

USE DBxd3;

CREATE TABLE Jugador(

    ID INT AUTO_INCREMENT PRIMARY KEY,
    name varchar(55) not null,
    email varchar(55) not null,
    password varchar(55) not null,
    edad int not null

);